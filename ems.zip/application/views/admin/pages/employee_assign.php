<meta http-equiv="Refresh" content="2; url=<?php echo site_url('admin/employee_list');?>">

<center>  
<h1> Redirecting to the employee list in 2 seconds </h1>
</center>