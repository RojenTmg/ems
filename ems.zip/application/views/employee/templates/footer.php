  	<!-- page-content-ends" -->
	</div>
	<!-- page-wrapper -->
   <script type="text/javascript" src="<?= base_url('assets/js/ems.js') ?>"></script>
	
</body>
</html>